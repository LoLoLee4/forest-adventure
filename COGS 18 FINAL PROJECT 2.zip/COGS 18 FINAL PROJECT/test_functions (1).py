"""Test for my functions. """

from functions import journey, intro, play_again
##
##

def test_journey():

    assert isinstance(journey(health), int)

def test_intro():

    assert isinstance(intro(name), str)

def test_play_again():
    
    assert isinstance(play_again(ans), str)
    

    try:
        isinstance(play_again(ans), int)
    except ValueError:
        assert True

!pytest tests.py             
    