"""A collection of function for doing my project."""
import time
import sys

def play_again():
    """ function called when player dies """ 
    ans = input("How unfortunate... Would you like to go back to the beginning? (yes/no)").lower()
    print()
    
    # evaluates conditional & either starts story over or ends story sequence
    if ans == 'yes':
        print('Good luck.')
        print()
        intro()
        
    elif ans == 'no':
        print('Farewell')
        sys.exit()



def intro():
    """ prompts input for player name/age, facilitates set up for the player's game """
    
    print("Oh finally... you're awake! You were out for quite some time.")
    print()
    # 'time' commands to add breaks between 'print' outputs
    time.sleep(1)

    # Creates a character by asking for player's name/age and decides if they are old enough to continue with the game 
    name = input('What is your name? ')
    print()
    time.sleep(2)
    
    age = int(input('What a lovely name. How old are you? '))
    int(age)
    print()
    time.sleep(2)

    if age >= 16:
        print('You seem like an experienced traveler,',name, '. You must now continue on your journey.')
        print()
        time.sleep(2)
    
        wants_to_play = input('Are you prepared? (yes/no) ').lower()
        print()
        time.sleep(2)
    
        if wants_to_play == 'yes':
            print("Your confidence is comforting...")
            print()
            print()
            time.sleep(2)
        
            print('** Health bar: 10 health. **')
            print()
            time.sleep(2)
    
            # sets value for 'weapon' to later be evaluated to decide story ending
            global weapon
            weapon = input('Wait! Before you go, take one of these tools: (sword/wand/none) ').lower()
            time.sleep(2)
            print()
            
            # after player makes choice of weapon, calls in 'journey' function to continue story sequence
            if weapon == 'sword':
                print('A sword... Interesting choice... Hopefully it is useful later... Your life may depend on it.')
                print()
                time.sleep(2)
                journey()
                
            elif weapon == 'wand':
                print('A wand... Interesting choice... Hopefully it is useful later... Your life may depend on it.')
                print()
                time.sleep(2)
                journey()
            
            else:
                print('Nothing? Curious choice, perhaps you think you alone can conquer the mysteries of the forest. Hopefully that mindset does not make a fool of you in the future...')
                print()
                print()
                time.sleep(2)
                journey()
                
        elif wants_to_play == 'no':
            print("Perhaps you're right... You should rest some more and try again another day...")
            time.sleep(2)
            play_again()
    
    else:
        print('Oh dear, young one, you must stay behind with me so the forest does not consume you! I am afraid I must say your journey is ending before it fully began...')
        time.sleep(2)
        play_again()
    



def journey():
    """ holds all possible story choices and runs the path dictated by the player's choices throughout """

    health = 10
    
    print('You embark on your journey.')
    print()
    time.sleep(1)
    
    print('You come across a split in the path, which way do you go...')
    time.sleep(1)
    
    choice = input('left or right? ').lower()
    time.sleep(2)
    print()
    
    # calls in 'play_again' function to restart the game when player 'dies'
    if choice == 'right':
        print('You have been lost.')
        time.sleep(2)
        print()
        
        play_again()
    
    if choice == 'left':
        
        print('You go down the left path and reach a large, shimmering lake...')
        time.sleep(2)
        ans = input('Do you swim across or go around? (across/around) ').lower()
        time.sleep(2)
        print()
        
        # decreases 'int' value of variable 'health' when player gets injured
        if ans == 'around':
            print('You went around and even though it took longer, you safely reached the other side of the lake.')
            time.sleep(2)
            print()
            print()
            
            
        elif ans == 'across':
            time.sleep(2)
            print('You swim across the lake, but before you can make it to the other side, a water snake with glowing purple skin bites your leg causing you to lose 5 health.')
            health -= 5
            print()
            time.sleep(2)    
            print('You now have', health, 'health. You really should be more careful.')
            time.sleep(2)
            print()
            print()
            
    
    print('With the lake now far behind you, you see a river and a house ahead of you.')
    time.sleep(2)
    print()
    print('The house is large and oddly shaped... but there may be someone inside who can help you.')
    time.sleep(2)
    print()
    print('The river is dark and mysterious, but something about it seems to be pulling at you.')
    
    time.sleep(2)
    ans = input('Do you go to the house or the river? (house/river) ').lower()
    print()
            
    if ans == 'house':
        print("You go to the house and as you approach the door opens to reveal a large creature with the wings of an eagle and the body of a lion...")
        time.sleep(2)
        print()
        print("It doesn't like visitors, so it attacks you!")
        print()
        print()
                
        # prints story ending & ends all running functions within the system
        if weapon == 'wand':
            time.sleep(2)
            print('You use your wand to cast a spell that puts the beast to sleep and you escape untouched!')
            print()
            time.sleep(2)
            print('You run away from the house and see the edge of the forest just in sight!')
            time.sleep(2)
            print()
            print('As you get closer you see the blinding light of the unknown that lies beyond the thick forest.')
            time.sleep(2)
            print()
            print('You burst out of the treeline into the blinding light, free of the shadows behind you and...')
            time.sleep(1)      
            print()
            print()
            time.sleep(1)
            print()
            print()
            time.sleep(1)
            print()
            print()
            time.sleep(1)      
            print("Creator: 'Well done, little one. I know it was challenging down there, but you've proven yourself as worthy. Now you may find true peace.'")
            sys.exit()
        
        elif weapon == 'sword':
            time.sleep(2)
            print('By the time you pull out your sword, the beast has already clawed you.')
            print()
            print('You manage to defeat the beast, but your cut is deep and you have lost 5 health...')
            print()
                      
            health -=5
            
            if health <= 0:
                time.sleep(2)
                print('The injuries you sustained were too much and you have lost all your health... your journey has come to an end...')
                print()
                play_again()
                
            else:
                print('Despite your injuries, you have survived...')
                
                print('You run away from the house and see the edge of the forest just in sight!')
                time.sleep(2)
                print()
                print('As you get closer you see the blinding light of the unknown that lies beyond the thick forest.')
                time.sleep(2)
                print()
                print('You burst out of the treeline into the blinding light, free of the shadows behind you and...')
                time.sleep(1)      
                print()
                print()
                time.sleep(1)
                print()
                print()
                time.sleep(1)
                print()
                print()
                time.sleep(1)      
                print("Creator: 'Well done, little one. I know it was challenging down there, but you've proven yourself as worthy. Now you may find true peace.'")
                sys.exit()
        else:
            time.sleep(2)
            print("The beast strikes you down... probably would've been nice to have had something to defend yourself with...")    
            print()
            play_again()
         
                
    else:
        print('The creatures lurking in the murky water have dragged you under... You are lost.')
        print()
        play_again()
                
        
        
        
# Start Game Below
intro()