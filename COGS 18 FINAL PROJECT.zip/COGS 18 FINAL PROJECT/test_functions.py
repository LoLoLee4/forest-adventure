"""Test for my functions. """
import mock


from functions import journey, intro, play_again
##
##

def test_journey():

    assert isinstance(journey(health), int)
    
import module
    
class TestIntro:
    
    def test_intro_1(self):
        module.input = lambda: 'yes'
        output = intro()
        assert output == 'Your confidence is comforting...'
        
    def test_intro_2(self):
        module.input = lambda: 'no'
        output = intro()
        assert output == "Perhaps you're right... You should rest some more and try again another day..."
    
    def teardown_method(self, method):
        module.input = input


class TestPlayAgain:
    
    def test_play_again_1(self):
        module.input = lambda: 'left'
        output = play_again()
        assert output == 'You go down the left path and reach a large, shimmering lake...'
        
    def test_play_again_2(self):
        module.input = lambda: 'right'
        output = play_again()
        assert output == 'You have been lost.'
    
    def teardown_method(self, method):
        module.input = input